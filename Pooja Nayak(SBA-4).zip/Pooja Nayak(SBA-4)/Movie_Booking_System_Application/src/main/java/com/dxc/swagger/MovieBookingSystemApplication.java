package com.dxc.swagger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

/*Main method */

@SpringBootApplication
public class MovieBookingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieBookingSystemApplication.class, args);
		
	}	
	
	/*For testing */
	
		@Bean
		public RestTemplate getRestTemplate() {
			
			return new RestTemplate();
		
		
	}

}
