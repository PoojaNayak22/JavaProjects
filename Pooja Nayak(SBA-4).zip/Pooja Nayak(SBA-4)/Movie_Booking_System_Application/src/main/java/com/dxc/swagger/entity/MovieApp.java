package com.dxc.swagger.entity;

/*Author : Pooja Nayak*/

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.stereotype.Component;


/*Author : Pooja Nayak*/

/*Pojo class for the movie application */


@Entity
@Component
public class MovieApp {
	
	/*list of entities as below*/
	@Id
	private int movieId;
	private String movieName;
	private double movieRating;
	private double movieDuration;
	private String movieCategory;
	private String movieRecommend;
	
	public int getMovieId() {
		return movieId;
	}
	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public double getMovieRating() {
		return movieRating;
	}
	public void setMovieRating(double movieRating) {
		this.movieRating = movieRating;
	}
	public double getMovieDuration() {
		return movieDuration;
	}
	public void setMovieDuration(double movieDuration) {
		this.movieDuration = movieDuration;
	}
	public String getMovieCategory() {
		return movieCategory;
	}
	public void setMovieCategory(String movieCategory) {
		this.movieCategory = movieCategory;
	}
	public String getMovieRecommend() {
		return movieRecommend;
	}
	public void setMovieRecommend(String movieRecommend) {
		this.movieRecommend = movieRecommend;
	}
	@Override
	public String toString() {
		return "MovieApp [movieId=" + movieId + ", movieName=" + movieName + ", movieRating=" + movieRating
				+ ", movieDuration=" + movieDuration + ", movieCategory=" + movieCategory + ", movieRecommend="
				+ movieRecommend + "]";
	}
	
	
	

}
