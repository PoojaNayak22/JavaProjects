package com.dxc.swagger.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.dxc.swagger.entity.MovieApp;
import com.dxc.swagger.repository.IMovieAppRepo;

/*Service class which implementing service interface*/

@Service
public class MovieAppService implements IMovieAppService{
	
	@Autowired
	IMovieAppRepo repo;

	/*calling predefined methods for the crud operation  */
	

	@Override
	public MovieApp insertMovieDetails(MovieApp movieapp) {
		return repo.save(movieapp);
	}

	@Override
	public void deleteMovieById(int id) {
		repo.deleteById(id);
	}

	@Override
	public List<MovieApp> getAllMoviesList() {
		
		return repo.findAll();
	}

}
