package com.dxc.swagger.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dxc.swagger.entity.MovieApp;

/*Repository Interface extending predefined Interface*/

public interface IMovieAppRepo extends JpaRepository<MovieApp, Integer>{

}
