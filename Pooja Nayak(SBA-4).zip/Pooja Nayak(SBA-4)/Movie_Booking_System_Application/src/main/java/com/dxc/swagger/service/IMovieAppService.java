package com.dxc.swagger.service;

import java.util.List;

/*Service Interface for the appliaction */

import com.dxc.swagger.entity.MovieApp;

public interface IMovieAppService {

	public MovieApp insertMovieDetails(MovieApp movieapp);

	public void deleteMovieById(int id);

	public List<MovieApp> getAllMoviesList();

}
