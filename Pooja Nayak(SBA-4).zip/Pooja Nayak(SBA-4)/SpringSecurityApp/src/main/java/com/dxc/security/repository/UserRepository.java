package com.dxc.security.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dxc.security.entities.User;

/*Dao layer for the application..which extends predefined interface*/

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
	
				
		User 	findByUsername(String username);
				
				
	

}
