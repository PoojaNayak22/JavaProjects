package com.dxc.service;

public interface IBankApplicationService {
	
	public void openBankAccount();
	public void depositBalance();
	public void totalBalance();
	public void withdraw() ;
	public void lessBalance();
}
