package com.dxc.service;

import org.springframework.stereotype.Component;

@Component
public class BankApplication implements  IBankApplicationService{
	
	
	public void openBankAccount() {
		
		String customerName="Pooja";
		String emailId="pooja12@gmail.com";
		long phoneNumber=98786787;
		int age=23;
		
		System.out.println(customerName+" "+emailId+" "+phoneNumber+" " + age);
	}
	
	
	public void depositBalance() {
		
		int depositAmount=20000;
		
		System.out.println("Money deposited to your account:"+depositAmount);
		
		}
	
	
	
	     public void totalBalance() {
		
		System.out.println("Your balance is:"+40000 );
		
	}
	
	
	public void withdraw() {
		
		System.out.println("amount withdrawn from your account");
		
		
		
	}
	
	public void lessBalance() {
		
		int amount=5000;
		
		if(amount<500) {
			
			System.out.println("you have a minimum balance..");
			
		}
	}
	

}
