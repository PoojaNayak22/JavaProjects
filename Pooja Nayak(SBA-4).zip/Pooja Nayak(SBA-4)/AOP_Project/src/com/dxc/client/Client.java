package com.dxc.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.dxc.service.BankApplication;

public class Client {

	public static void main(String[] args) {
		
		
		
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		
		
		 BankApplication bankservice =	context.getBean(BankApplication.class);	 
		      
		 bankservice.openBankAccount();
		       
		 bankservice.depositBalance();
		
		 bankservice.totalBalance();
		 
		
		 bankservice.withdraw();
				 		
		 bankservice.lessBalance();
		
		
		

	}

}
