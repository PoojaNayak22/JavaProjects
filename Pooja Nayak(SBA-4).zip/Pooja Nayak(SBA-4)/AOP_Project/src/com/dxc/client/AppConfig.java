package com.dxc.client;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = { "com.dxc.service","com.dxc.aspect","com.dxc.client"})
public class AppConfig {
	
	
	

}
