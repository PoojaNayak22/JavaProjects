package com.dxc.aspect;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Component;

@Aspect
@Component
@EnableAspectJAutoProxy
public class AspectImplementation {

		@Before("execution(public void openBankAccount())")
		
		public void createAccount() {
			
			System.out.println("New Account open process..");
		}
	
		@After("execution(public void openBankAccount())")
		public void logging() {
			
			System.out.println("New Account is opened..");
		}
	
		
		@AfterReturning("execution(public void depositBalance())")
		public void depositTransaction() {
			
			System.out.println("Money is deposited to your account");
			
		}
		
		
		@Around("execution(public void withdraw())")
		public void withdrawBalance() {
			
			System.out.println("5000 is withdrawn from your account");
			
		}
		
	    @AfterThrowing("execution(public void lessBalance())")
		public void MinBalance() {
			
			System.out.println("your amount is less in your account..");
			
		}
	
	
}
