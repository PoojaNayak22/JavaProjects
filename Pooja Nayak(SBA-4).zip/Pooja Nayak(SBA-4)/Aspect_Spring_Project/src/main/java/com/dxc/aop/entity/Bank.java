package com.dxc.aop.entity;

public class Bank {
	
	private String bankName;
	private String emailId;
	private long phoneNumber;
	private int age;
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "Bank [bankName=" + bankName + ", emailId=" + emailId + ", phoneNumber=" + phoneNumber + ", age=" + age
				+ "]";
	}
	
	
	

	

}