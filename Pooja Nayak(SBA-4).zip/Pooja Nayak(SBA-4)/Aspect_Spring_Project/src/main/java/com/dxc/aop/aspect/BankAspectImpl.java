package com.dxc.aop.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class BankAspectImpl {

	@Before(value = "execution(* com.dxc.aop.service.BankService.*(..)) and args(name,email,phone,age)")
	public void beforeAdvice(JoinPoint joinPoint, String name, String email,long phone,int age) {
		System.out.println("Before method:" + joinPoint.getSignature());

		System.out.println("Creating the BankName - " + name + " and emailId - " + email+"phone"+phone+"age"+age);
	}

	@After(value = "execution(* com.dxc.aop.service.BankService.*(..)) and args(name,email,phone,age)")
	public void afterAdvice(JoinPoint joinPoint, String name, String email,long phone,int age) {
		System.out.println("After method call :" + joinPoint.getSignature());

		System.out.println("Successfully created Bank with name - " + name + " and emailId - " + email+"phone"+phone+"age"+age);
	}
	@Pointcut(value= "execution(* com.dxc.aop.service.BankService.*(..))")  
	private void logDisplayingBalance()   
	{   
	}  
	@Around(value= "logDisplayingBalance()")  
	public void aroundAdvice(ProceedingJoinPoint jp) throws Throwable   
	{  
	System.out.println("The method aroundAdvice() before invokation of the method " + jp.getSignature().getName() + " method");  
	try   
	{  
	jp.proceed();  
	}   
	finally   
	{  
	  
	}  
	System.out.println("The method aroundAdvice() after invokation of the method " + jp.getSignature().getName() + " method");  
	}  
}
