package com.dxc.aop.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dxc.aop.entity.Bank;
import com.dxc.aop.service.BankService;

@RestController
public class BankController {

	@Autowired
	private BankService service;

	@RequestMapping(value = "/insert/bank", method = RequestMethod.GET)
	public Bank addEmployee(@RequestParam("name") String name, @RequestParam("email") String email,@RequestParam("phone") long phone,@RequestParam("age") int age) {

		return service.createBank(name,email,phone,age);

	}

	
}