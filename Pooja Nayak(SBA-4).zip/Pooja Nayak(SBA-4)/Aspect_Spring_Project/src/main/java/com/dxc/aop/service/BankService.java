package com.dxc.aop.service;

import org.springframework.stereotype.Service;

import com.dxc.aop.entity.Bank;

@Service
public class BankService {

	public Bank createBank(String name,String email,long phone,int age) {

		Bank employee = new Bank();
		employee.setBankName(name);
		employee.setEmailId(email);
		employee.setPhoneNumber(phone);
		employee.setAge(age);
		
		return employee;
	}
	
	public void displayBalance(String accountNumber)   
	{  
	System.out.println("Inside displayBalance() method");  
	if( accountNumber.equals("986789"))   
	{  
	System.out.println("your account balance is: 50,000");  
	}  
	else   
	{  
	System.out.println("Sorry! you entered wrong account number.");  
	}  
	}  

}