package com.dxc.aop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import com.dxc.aop.service.BankService;

@SpringBootApplication
@EnableAspectJAutoProxy(proxyTargetClass=true)
public class AspectProjectApplication {

	public static void main(String[] args) {
		ConfigurableApplicationContext context = SpringApplication.run(AspectProjectApplication.class, args);
		
		BankService service= context.getBean(BankService.class);  
		
		String accountNumber = "986789";  
		
		service.displayBalance(accountNumber);  
		
		context.close();
	}
}